### Elephant Posture Project: NetFACS analysis of elephant interaction posture data - specificity and probability networks
### Based on script by Kate Lewis NetFACS analysis of EquiFACS horse-horse data - specificity and probability networks https://osf.io/xtngb
# Created on: 09/10/2025 AMBO & APNR data only
# Updated on: 09/05/2026 
# Owner: Tapinder Sidhu


###################################################################################################################

## Prepare environment ##

# Clear environment
rm(list=ls())

setwd("F:/06_Data_Analysis/PostureFilesAnalysis") #set working directory

###################################################################################################################

## Install packages ##

# will install development version of NetFACS: v0.5.0.9001
remove.packages("NetFACS")
#install.packages("remotes")
library(remotes)
remotes::install_github("NetFACS/NetFACS", ref = "73c2a29b")

#install.packages("tidyverse")
library(tidyverse)
library(NetFACS)
library(ggraph)
# install.packages("ggbeeswarm")
library(ggbeeswarm) # for point distribution plot


###################################################################################################################

## Upload and upsample data ##

# upload data
full.data <- read.csv("Data/Posture_ForNetFACS_AMBOAPNR.csv")

# UPSAMPLE - as imbalanced number of observations per group causes specificity results to be biased

# First check current numbers of each behaviour
head(full.data %>% count(CSubcat), n=22)

#CSubcat   n
#1 Affiliative 617
#2   Agonistic 894
#3     Evasive 676

# randomly upsample minority conditions to have the same number of observations as the majority condition

set.seed(2)

full.data.upsampled <- upsample(full.data, 
                               condition = full.data$CSubcat)
# check it has worked
print(full.data.upsampled %>% count(CSubcat), n=22) # all conditions now have 894 observations


# SPLIT full.data.upsampled into seperate DATA AND INFO dfs (needed in this format for running multi.facs)
au.info <- full.data.upsampled %>% select(X:Activity)
au.data <- full.data.upsampled %>% select(EFold:HfStToe)


# check same number of rows in each
nrow(au.data)
nrow(au.info)
#2682

# convert data to numeric, NA coercion is ok
au.data <- 
  au.data %>% 
  mutate(across(everything(), as.numeric)) %>% 
  as.matrix()

head(au.data)


##################################### ANALYSIS BY BEHAVIOURAL GROUPS ############################################################


#### WITH MULTIFACS ####


set.seed(20255) 

# this code is what netfacs.multiple does under the hood
# I'm coding it manually here because netfacs.multiple does not currently work when the data has NAs.
conditions <- sort(unique(au.info$CSubcat))
ran.trials <- 1000
multi.facsCCupdateA <- lapply(conditions, function(x) {
  xx <- netfacs_na(
    data = au.data,
    condition = au.info$CSubcat,
    test.condition = x,
    ran.trials = ran.trials, 
    combination.size = 2,
    control = data.frame(Sex = au.info$Sex),  # add Sex as control
    random.level = au.info$RC,            # add RC as random level
    use_parallel = TRUE,
    n_cores = parallel::detectCores()-1
  )
  return(xx)
})
names(multi.facsCCupdateA) <- conditions
# set class and attributes
multi.facsCCupdateA <- structure(
  multi.facsCCupdateA, 
  class = "netfacs_multiple",
  stat_method = "bootstrap",
  random_trials = ran.trials
)


# save multi.facs object for later use
saveRDS(multi.facsCCupdateA, file="multi.facsCCupdateA.rds")

# load multi.facs object
multi.facsCCupdateA <- readRDS("multi.facsCCupdateA.rds")


# extract overall results with pvalues
(resCCupdateA <- netfacs_extract(multi.facsCCupdateA))
view(resCCupdateA)

write.csv(resCCupdateA, "Data/NetFACSExtractMultiFacsResContextsforSpecificityUpdateA.csv")

##########################################################################################################

#### CALCULATING SPECIFICITY ####

library(dplyr)

# netfacs() function no longer calculates specificity, so it has to be calculated separately
# imbalanced number of observations per group causes specificity results to be biased


# calculate specificity from netfacs results 
set.seed(1)
sp <- specificity(
  multi.facsCCupdateA, 
  combination.size = 3, 
  upsample = TRUE # makes sure data is upsampled before calculating specificity. If FALSE, will calculate specificity on original imbalanced data.
)

write.csv(sp, "Data/NetFACSSpecificityResultsUpdateA.csv")

spec.increase <- specificity_increase(sp)
spe <- as.data.frame(spec.increase$element)
spd <- as.data.frame(spec.increase$dyad)

write.csv(spe, "Data/NetFACSSpecificityIncreaseElementResultsUpdateA.csv")
write.csv(spd, "Data/NetFACSSpecificityIncreaseDyadResultsUpdateA.csv")


# view combinations with top 5 highest specificity per context
sp1C <- sp %>% 
  group_by(condition) %>% 
  slice_max(order_by = specificity, n = 5)

# view combinations with top 5 observed probabilities per context
sp %>% 
  group_by(condition) %>% 
  slice_max(order_by = observed.prob, n = 5)

# consider filtering for combinations that are common AND have high specificity
sp3C <- sp %>% 
  filter(
    observed.prob >= 0.5, # combinations present in at least 50% of obs
    specificity >= 0.5, 
  ) 

# plot networks 
multi.netupdateA <- multiple_netfacs_network(multi.facsCCupdateA, min.prob = 0.2)
multi.netupdateA.plot <- multiple_network_plot(multi.netupdateA)

jpeg("Figures/MultiNetupdateA.jpeg")
multi.netupdateA.plot
dev.off()


ag.netupdateA <- netfacs_network(multi.facsCCupdateA$Agonistic,  min.prob = 0.15) 
ag.netupdateA.plot <- network_plot(ag.netupdateA, title = "Agonistic", plot.bubbles = TRUE)

jpeg("Figures/AgonisticProbNetupdateA.jpeg")
ag.netupdateA.plot
dev.off()

nonag.netupdateA <- netfacs_network(multi.facsCCupdateA$Affiliative,  min.prob = 0.15) 
nonag.netupdateA.plot <- network_plot(nonag.netupdateA, title = "Affiliative", plot.bubbles = TRUE)

jpeg("Figures/AffiliativeProbNetupdateA.jpeg")
nonag.netupdateA.plot
dev.off()

ev.netupdateA <- netfacs_network(multi.facsCCupdateA$Evasive,  min.prob = 0.15) 
ev.netupdateA.plot <- network_plot(ev.netupdateA, title = "Evasive", plot.bubbles = TRUE)

jpeg("Figures/EvProbNetupdateA.jpeg")
ev.netupdateA.plot
dev.off()

################################################################################

#### SPECIFICITY and PROBABILITY OVERLAP NETWORKS ####


overlap.netupdateA <- overlap_network(
  sp,
  min.prob = 0, # minimum probability of a connection to be included
  min.count = 5, # minimum count of co-occurrences for a connection to be included 
  significance = 0.01, # significance level for combinations to be considered
  clusters = FALSE, # should the bipartite network be clustered
  plot.bubbles = TRUE,
)

MultiNetSpecificityupdateA <- plot(overlap.netupdateA$specificity)

jpeg("Figures/MultiNetSpecificityupdateA.jpeg")
MultiNetSpecificityupdateA
dev.off()

MultiNetOccuranceProbupdateA <- plot(overlap.netupdateA$occurrence)

jpeg("Figures/MultiNetOccuranceProbupdateA.jpeg")
MultiNetOccuranceProbupdateA
dev.off()


# CREATE CUSTOM PLOTS

min_prob <- 0.1

d2 <- 
  sp |> 
  rename(context = condition,
         count = count) %>%
  # keep single AUs only
  filter(!str_detect(combination, "_")) |> 
  filter(
    combination.size == 1,
    observed.prob >= min_prob
  ) %>%
  select(context, combination, specificity) 

gl <- 
  d2 %>%
  igraph::graph_from_data_frame(directed = TRUE, vertices = NULL) %>%
  tidygraph::as_tbl_graph()

au_color="steelblue"
context_color = "salmon"

gl2 <-
  gl %>%
  tidygraph::activate(nodes) %>%
  mutate(
    type = igraph::bipartite_mapping(.)$type,
    color = ifelse(type, au_color, context_color),
    shape = "bold"
  )

# create layout first so the we can access the coordinates
gl2b <-
  gl2 %>%
  create_layout(
    layout = "igraph",
    algorithm = "fr"
  )

edge_color = "#404040"
context_color = "#0f85a0"
au_color = "#ed8b00"
node_text_size = 3
theme_text_size = 14

gl3 <-
  gl2b %>%
  ggraph() +
  geom_edge_fan(
    aes(alpha = specificity,
        width = specificity),
    colour = edge_color,
  ) +
  geom_node_label(
    aes(label = name,
        fontface = shape),
    color = gl2b$color,
    size = node_text_size,
    show.legend = FALSE
  ) +
  theme_graph(
    base_family = "sans"
  ) +
  scale_edge_alpha_continuous(
    name = "Specificity:",
    limits = c(0,1),
    breaks = c(0.25,0.5,0.75)
  ) +
  scale_edge_width(
    name = "Specificity:",
    range = c(1, 3.5),
    limits = c(0,1),
    breaks = c(0.25,0.5,0.75)
  ) +
  theme(
    plot.title = element_text(
      face = "plain",
      size = theme_text_size,
      vjust = -5),
    legend.text = element_text(size = theme_text_size),
    legend.title = element_text(size = theme_text_size),
    plot.margin = grid::unit(c(-1,-1,-1,-1), "mm"),
    legend.position = c(0.8,0.15)
  )

# Save the plot
ggsave("Figures/SpecificityNetPlotupdateA.png", plot = gl3, width = 10, height = 8, dpi = 300)


# DO FOR PAIRS 
d2 <- 
  sp |> 
  rename(context = condition,
         count = count) %>%
  # keep pair AUs only
  filter(
    combination.size == 2,
    observed.prob >= min_prob
  ) %>%
  select(context, combination, specificity) 

gl <- 
  d2 %>%
  igraph::graph_from_data_frame(directed = TRUE, vertices = NULL) %>%
  tidygraph::as_tbl_graph()

au_color="steelblue"
context_color = "salmon"

gl2 <-
  gl %>%
  tidygraph::activate(nodes) %>%
  mutate(
    type = igraph::bipartite_mapping(.)$type,
    color = ifelse(type, au_color, context_color),
    shape = "bold"
  )

# create layout first so the we can access the coordinates
gl2b <-
  gl2 %>%
  create_layout(
    layout = "igraph",
    algorithm = "fr"
  )

edge_color = "#404040"
context_color = "#0f85a0"
au_color = "#ed8b00"
node_text_size = 3
theme_text_size = 14

gl3 <-
  gl2b %>%
  ggraph() +
  geom_edge_fan(
    aes(alpha = specificity,
        width = specificity),
    colour = edge_color
  ) +
  geom_node_label(
    aes(label = name,
        fontface = shape),
    color = gl2b$color,
    size = node_text_size,
    max.overlaps = Inf,
    show.legend = FALSE
  ) +
  theme_graph(base_family = "sans") +
  scale_edge_alpha_continuous(
    name = "Specificity:",
    limits = c(0,1),
    breaks = c(0.25,0.5,0.75)
  ) +
  scale_edge_width(
    name = "Specificity:",
    range = c(1, 3.5),
    limits = c(0,1),
    breaks = c(0.25,0.5,0.75)
  ) +
  coord_equal(clip = "off", expand = TRUE) +
  theme(
    legend.text = element_text(size = theme_text_size),
    legend.title = element_text(size = theme_text_size),
    plot.margin = grid::unit(c(10, 10, 10, 10), "mm"),
    legend.position = c(0.95, 0.95),
    legend.justification = c("right", "top")
  )

ggsave(
  "Figures/SpecificityNetPlotupdateAPAIRS.png",
  plot = gl3,
  width = 12,
  height = 8,
  dpi = 300
)

#overlap_net_patch <-
#  patchwork::wrap_plots(gl3) +
#  patchwork::plot_layout(ncol = 1, guides = "collect") &
# theme(legend.position = "bottom")





## customised probability plot


p2 <- 
  sp |> 
  rename(context = condition,
         count = count) %>%
  # keep single AUs only
  filter(!str_detect(combination, "_")) |> 
  filter(
    combination.size == 1,
    observed.prob >= min_prob
  ) %>%
  select(context, combination, observed.prob) 

op <- 
  p2 %>%
  igraph::graph_from_data_frame(directed = TRUE, vertices = NULL) %>%
  tidygraph::as_tbl_graph()


au_color="steelblue"
context_color = "salmon"

op2 <-
  op %>%
  tidygraph::activate(nodes) %>%
  mutate(
    type = igraph::bipartite_mapping(.)$type,
    color = ifelse(type, au_color, context_color),
    shape = "bold"
  )

# create layout first so the we can access the coordinates
op2b <-
  op2 %>%
  create_layout(
    layout = "igraph",
    algorithm = "fr"
  )


edge_color = "#404040"
context_color = "#0f85a0"
au_color = "#ed8b00"
node_text_size = 4
theme_text_size = 14

(op3 <-
    op2b %>%
    ggraph() +
    geom_edge_fan(
      aes(alpha = observed.prob,
          width = observed.prob),
      colour = edge_color,
    ) +
    geom_node_label(
      aes(label = name,
          fontface = shape),
      # color = .x[["color"]],
      color = gl2b$color,
      size = node_text_size,
      show.legend = FALSE
    ) +
    theme_graph(
      base_family = "sans"
    ) +
    scale_edge_alpha_continuous(
      name = "Occurrence Probability",
      limits = c(0,1),
      breaks = c(0.25,0.5,0.75)
    ) +
    scale_edge_width(
      name = "Occurrence Probability",
      range = c(1, 3.5),
      limits = c(0,1),
      breaks = c(0.25,0.5,0.75)
    ) +
    # so that nodes are not cut off when saving
    # coord_cartesian(
    #   xlim = c(min(.x$x) - 0.35, max(.x$x) + 0.35),
    #   ylim = c(min(.x$y) - 0.35, max(.x$y) + 0.35)
    # ) +
    theme(
      plot.title = element_text(
        face = "plain",
        size = theme_text_size,
        vjust = -5),
      legend.text = element_text(size = theme_text_size),
      legend.title = element_text(size = theme_text_size),
      plot.margin = grid::unit(c(-1,-1,-1,-1), "mm"),
      legend.position = c(0.2,0.2)
    )
)

# Save the plot
ggsave("Figures/ProbNetPlotupdateA.png", plot = op3, width = 10, height = 8, dpi = 300)


#overlap_net_patch <-
#  patchwork::wrap_plots(gl3) +
#  patchwork::plot_layout(ncol = 1, guides = "collect") &
# theme(legend.position = "bottom")

################################################################################

#### SPECIFICITY VIOLIN PLOTS ####


# summarise specificity results
sp.summary <- 
  sp %>% 
  # optional filtering. 
  # The combination count should be at least the same number as the number of conditions. Otherwise an AU combination that is only observed once will have a specificity of 1, but only because it never had the chance to be observed in another context.
  filter(
    observed.prob >= 0.10, # combination observed in >= 10% of cases
    count >= length(unique(sp$condition))
  ) %>%
  group_by(condition) %>%
  summarise(across(
    specificity,
    list(
      mean = mean,
      median = median,
      min = min,
      max = max,
      sd = sd,
      n = ~n()
    ),
    .names = "{.fn}"
  ), .groups = "keep")

write.csv(sp.summary, "Data/NetFACSSpecificityContextsupdateA")

SpecContupdateA.plot <- sp %>%
  filter(
    observed.prob >= 0.10, 
    count >= length(unique(sp$condition))
  ) %>%
  ggplot(aes(condition, specificity, 
             color = condition, fill = condition)) +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        panel.background = element_blank(), axis.line = element_line(colour = "black"),
        axis.title = element_text(size = 15, face = "bold"),
        axis.title.y = element_text(margin = margin(t = 0, r = 10, b = 0, l = 0)),
        axis.title.x = element_text(margin = margin(t = 10, r = 0, b = 0, l = 0)),
        axis.text = element_text(size = 13, color = "black")) +
  geom_violin(alpha = 0.2,
              show.legend = FALSE) +
  geom_point(position = position_jitter(width = 0.3),
             show.legend = FALSE,
             alpha = 0.15) +
  geom_point(data = sp.summary,
             aes(condition, mean),
             show.legend = FALSE,
             fill = "white",
             color = "black",
             shape = 23,
             size = 3.5) +
  xlab("Context") +
  ylab("Specificity") +
  scale_x_discrete(
    limits = c("Affiliative", "Agonistic", "Evasive"),
    labels = c("Affiliative", "Agonistic", "Evasive")
  ) +
  scale_color_manual(
    values = c("Affiliative" = "light blue", "Agonistic" = "violet", "Evasive" = "light green")
  ) +
  scale_fill_manual(
    values = c("Affiliative" = "light blue", "Agonistic" = "violet", "Evasive" = "light green")
  )

# Save the plot
ggsave("Figures/SpecificityCSubcatViolinPlotupdateA.png", plot = SpecContupdateA.plot, width = 10, height = 8, dpi = 300)


################################################################################

#### SPECIFICITY POINT PLOT: SINGLE UNITS AND PAIRS ####

# SET FILTERING THRESHOLD ------------------------------------------------------

# Set minimum number of observations required for a combination
# to be included in the specificity plot
min_specificity_count <- 5


# PREPARE DATA -----------------------------------------------------------------

# Keep only:
# - combinations observed in at least 10% of cases
# - combinations with at least 5 observations
# - single units and pairs only
sp.points <- sp %>%
  filter(
    observed.prob >= 0.10,
    count >= min_specificity_count,
    combination.size %in% c(1, 2)
  ) %>%
  
  # Create variables for plotting
  mutate(
    
    # Label whether each combination is a single unit or a pair
    unit_type = case_when(
      combination.size == 1 ~ "Single units",
      combination.size == 2 ~ "Pairs"
    ),
    
    # Categorise specificity values into colour bands
    specificity_band = cut(
      specificity,
      breaks = c(-Inf, 0.50, 0.75, Inf),
      labels = c("≤ .50", ".51–.75", "> .75"),
      right = TRUE
    )
  )


# SUMMARY STATISTICS -----------------------------------------------------------

# Calculate descriptive statistics for each context
# and combination type
sp.summary <- sp.points %>%
  group_by(condition, unit_type) %>%
  summarise(
    mean = mean(specificity, na.rm = TRUE),
    median = median(specificity, na.rm = TRUE),
    min = min(specificity, na.rm = TRUE),
    max = max(specificity, na.rm = TRUE),
    sd = sd(specificity, na.rm = TRUE),
    n = n(),
    .groups = "drop"
  )

# Save summary table
write.csv(
  sp.summary,
  "Data/NetFACSSpecificityContextsSinglesPairsupdateA.csv",
  row.names = FALSE
)


# COUNT POINTS BY SPECIFICITY BAND ---------------------------------------------

# Count how many plotted points fall into each specificity category,
# split by context and combination type
sp.band.counts <- sp.points %>%
  group_by(condition, unit_type, specificity_band) %>%
  summarise(
    n_points = n(),
    .groups = "drop"
  )

# View count table
View(sp.band.counts)

# Save count table
write.csv(
  sp.band.counts,
  "Data/NetFACSSpecificityBandCountsSinglesPairsupdateA.csv",
  row.names = FALSE
)


# CREATE PLOT ------------------------------------------------------------------

# Plot all single-unit and pair specificity values.
# Quasirandom spreading makes the points reflect the underlying density
# while retaining individual points
SpecContupdateA.points.plot <- sp.points %>%
  
  ggplot(aes(
    
    # Behavioural context on x-axis
    x = condition,
    # Specificity value on y-axis
    y = specificity,
    # Colour points by specificity category
    colour = specificity_band,
    # Shape points by combination type
    shape = unit_type
  )) +
  # Spread points according to local density
  geom_quasirandom(
    # Keep single units and pairs as separate distributions within each context
    aes(group = interaction(condition, unit_type)),
    # Horizontal separation between single units and pairs
    dodge.width = 0.65,
    # Amount of horizontal spreading within each group
    width = 0.28,
    # Point transparency
    alpha = 0.75,
    # Point size
    size = 2.6
  ) +
  # Theme settings matched to the original specificity violin plot
  theme(
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    panel.background = element_blank(),
    axis.line = element_line(colour = "black"),
    axis.title = element_text(size = 15, face = "bold"),
    axis.title.y = element_text(
      margin = margin(t = 0, r = 10, b = 0, l = 0)
    ),
    axis.title.x = element_text(
      margin = margin(t = 10, r = 0, b = 0, l = 0)
    ),
    axis.text = element_text(size = 13, colour = "black")
  ) +
  # Axis labels
  xlab("Context") +
  ylab("Specificity") +
  # Set order of contexts on x-axis
  scale_x_discrete(
    limits = c("Affiliative", "Agonistic", "Evasive"),
    labels = c("Affiliative", "Agonistic", "Evasive")
  ) +
  # Specificity ranges from 0 to 1
  scale_y_continuous(
    limits = c(0, 1),
    breaks = c(0, 0.50, 0.75, 1)
  ) +
  # Colour points by specificity band
  scale_colour_manual(
    name = "Specificity",
    values = c(
      "≤ .50" = "#7A97B8",
      ".51–.75" = "#E69F00",
      "> .75" = "#7D1F3A"
    )
  ) +
  # Shape points by combination type
  scale_shape_manual(
    name = "Combination type",
    values = c(
      "Single units" = 16, # filled circle
      "Pairs" = 17         # filled triangle
    )
  )


ggsave(
  "Figures/SpecificityCSubcatSinglesPairsPointPlotupdateA.png",
  plot = SpecContupdateA.points.plot,
  width = 10,
  height = 8,
  dpi = 300
)

################################################################################

### EXTRACT SIG AU/ADs FOR EACH CONTEXT ####



## AGONISTIC ##

Agonistic.pus1aupdateA <- netfacs_extract(
  netfacs.data = multi.facsCCupdateA$Agonistic,
  combination.size = 1,
  min.count = 5,
  min.prob = 0,
  significance = 0.01)

View(agonistic.pus1aupdateA)
write.csv(Agonistic.pus1aupdateA, "Data/NetFACSAgonistic.pus1aupdateA.csv")

Agonistic.pus1aupdateAP <- netfacs_extract(
  netfacs.data = multi.facsCCupdateA$Agonistic,
  combination.size = 2,
  min.count = 5,
  min.prob = 0,
  significance = 0.01)

View(agonistic.pus1aupdateAP)
write.csv(Agonistic.pus1aupdateAP, "Data/NetFACSAgonistic.pus1aupdateAPAIRS.csv")

## NON AGONISTIC ##

Affiliative.pus1aupdateA <- netfacs_extract(
  netfacs.data = multi.facsCCupdateA$Affiliative,
  combination.size = 1,
  min.count = 5,
  min.prob = 0,
  significance = 0.01)

View(Affiliative.pus1aupdateA)
write.csv(Affiliative.pus1aupdateA, "Data/NetFACSAffiliative.pus1aupdateA.csv")

Affiliative.pus1aupdateAP <- netfacs_extract(
  netfacs.data = multi.facsCCupdateA$Affiliative,
  combination.size = 2,
  min.count = 5,
  min.prob = 0,
  significance = 0.01)

View(Affiliative.pus1aupdateAP)
write.csv(Affiliative.pus1aupdateAP, "Data/NetFACSAffiliative.pus1aupdateAPAIRS.csv")


## Evasive ##

Evasive.pus1aupdateA <- netfacs_extract(
  netfacs.data = multi.facsCCupdateA$Evasive,
  combination.size = 1,
  min.count = 5,
  min.prob = 0,
  significance = 0.01)

View(Evasive.pus1aupdateA)
write.csv(Evasive.pus1aupdateA, "Data/NetFACSEvasive.pus1aupdateA.csv")

Evasive.pus1aupdateAP <- netfacs_extract(
  netfacs.data = multi.facsCCupdateA$Evasive,
  combination.size = 2,
  min.count = 5,
  min.prob = 0,
  significance = 0.01)

View(Evasive.pus1aupdateAP)
write.csv(Evasive.pus1aupdateAP, "Data/NetFACSEvasive.pus1aupdateAPAIRS.csv")

################################################################################



## CONDITIONAL PROBABILITIES AND PLOTS ##

# get dyadic conditional probabilities
conditional.probs <- conditional_probabilities(multi.facsCCupdateA)

# split data into a list so that each element in the list is only one condition
conditional.probs.list <- 
  conditional.probs %>% 
  split(.$condition) %>% 
  map(~.x %>% select(-condition))

conditional.probs.list$Agonistic



# conditional probability network plots
net.conditional.probs <- 
  conditional.probs.list %>% 
  map(~.x %>% 
        # keep only the most common
        slice_max(order_by = count, n = 100) %>% 
        network_conditional())

net.conditional.probs$Agonistic$plot
net.conditional.probs$Affiliative$plot
net.conditional.probs$Evasive$plot


#################################################################################################

### CUSTOMISED NETWORK PLOTS ###

library(tidygraph)
library(ggraph)



# AGONISTIC #

#ag.netupdate <- 
#  netfacs_network(
#    multi.facsCCupdate$Agonistic, 
#    link = "raw",
#    min.prob = 0.2,
#    min.count = length(unique(multi.facsCCupdate$Agonistic$used.data$condition))
#  )

#network_plot(ag.netupdate, 
#             plot.bubbles = TRUE)
#network_plot(ag.netupdate)


#g <- 
#  ag.netupdate %>% 
#  activate(nodes) %>% 
#  # hide AUs not observed in this context
#  filter(element.prob != 0 | !is.na(element.prob)) #%>% 
## optionally keep only connections that are significant
## activate(edges) %>%
## filter(pvalue <= 0.05)


#g.nodes <- g %>% activate(nodes) %>% as_tibble()
#g.edges <- g %>% activate(edges) %>% as_tibble()

#g.layout <- 
#  g %>% 
#  create_layout(
#    layout = "igraph",
#    algorithm = "kk" # other options: "kk", nicely", "dh"
#  ) 

#agnetupdate.plot <- g.layout %>% 
#  ggraph() +
#  geom_edge_fan(
#    aes(alpha = observed.prob,
#        width = observed.prob)
#  ) +
#  geom_node_label(
#    aes(label = name),
#    color = "firebrick",
#    size = 4,
#    show.legend = FALSE
#  ) +
#  theme_graph(base_family = "sans") +
#  scale_edge_alpha_continuous(
#    name = "Probability\nof co-activation",
#    limits = c(0,1),
#    breaks = c(0.25,0.5,0.75)
#  ) +
#  scale_edge_width(
#    name = "Probability\nof co-activation",
#    limits = c(0,1),
#    breaks = c(0.25,0.5,0.75)
#  ) +
#  # extend border so that nodes are not cut off
#  coord_cartesian(
#    xlim = c(min(g.layout$x) - 0.35, max(g.layout$x) + 0.35),
#    ylim = c(min(g.layout$y) - 0.35, max(g.layout$y) + 0.35)
#  ) +
#  ggtitle("Agonistic network")
#
#jpeg("Figures/AgonisticNetupdate.jpeg")
#agnetupdate.plot
#dev.off()




# NON AGONISTIC #

#nonag.netupdate <- 
#  netfacs_network(
#    multi.facsCCupdate$Affiliative, 
#    link = "raw",
#   min.prob = 0.2,
#    min.count = length(unique(multi.facsCCupdate$Affiliative$used.data$condition))
#  )

#network_plot(nonagupdate.net, 
#             plot.bubbles = TRUE)
#network_plot(nonagupdate.net)


#g <- 
#  nonagupdate.net %>% 
#  activate(nodes) %>% 
#  # hide AUs not observed in this context
#  filter(element.prob != 0 | !is.na(element.prob)) #%>% 
## optionally keep only connections that are significant
## activate(edges) %>%
## filter(pvalue <= 0.05)


#g.nodes <- g %>% activate(nodes) %>% as_tibble()
#g.edges <- g %>% activate(edges) %>% as_tibble() 

#g.layout <- 
#  g %>% 
#  create_layout(
#    layout = "igraph",
#    algorithm = "kk" # other options: "kk", nicely", "dh"
#  ) 

#nonagnetupdate.plot <- g.layout %>% 
#  ggraph() +
#  geom_edge_fan(
#    aes(alpha = observed.prob,
#        width = observed.prob)
#  ) +
#  geom_node_label(
#    aes(label = name),
#    color = "firebrick",
#    size = 4,
#    show.legend = FALSE
#  ) +
#  theme_graph(base_family = "sans") +
#  scale_edge_alpha_continuous(
#    name = "Probability\nof co-activation",
#    limits = c(0,1),
#    breaks = c(0.25,0.5,0.75)
#  ) +
#  scale_edge_width(
#    name = "Probability\nof co-activation",
#    limits = c(0,1),
#    breaks = c(0.25,0.5,0.75)
#  ) +
#  # extend border so that nodes are not cut off
#  coord_cartesian(
#    xlim = c(min(g.layout$x) - 0.35, max(g.layout$x) + 0.35),
#    ylim = c(min(g.layout$y) - 0.35, max(g.layout$y) + 0.35)
#  ) +
#  ggtitle("Affiliative network")


#jpeg("Figures/AffiliativeNetupdate.jpeg")
#nonagnetupdate.plot
#dev.off()



# EVASIVE #

#ev.netupdate <- 
#  netfacs_network(
#    multi.facsCCupdate$Evasive, 
#    link = "raw",
#    min.prob = 0.2,
#    min.count = length(unique(multi.facsCCupdate$Evasive$used.data$condition))
#  )

#network_plot(ev.netupdate, 
#             plot.bubbles = TRUE)
#network_plot(ev.netupdate)


#g <- 
#  ev.netupdate %>% 
#  activate(nodes) %>% 
#  # hide AUs not observed in this context
#  filter(element.prob != 0 | !is.na(element.prob)) #%>% 
## optionally keep only connections that are significant
## activate(edges) %>%
## filter(pvalue <= 0.05)


#g.nodes <- g %>% activate(nodes) %>% as_tibble()
#g.edges <- g %>% activate(edges) %>% as_tibble() 

#g.layout <- 
#  g %>% 
#  create_layout(
#    layout = "igraph",
#    algorithm = "kk" # other options: "kk", nicely", "dh"
#  ) 

#evasivenetupdate.plot <- g.layout %>% 
#  ggraph() +
#  geom_edge_fan(
#    aes(alpha = observed.prob,
#        width = observed.prob)
#  ) +
#  geom_node_label(
#    aes(label = name),
#    color = "firebrick",
#    size = 4,
#    show.legend = FALSE
#  ) +
#  theme_graph(base_family = "sans") +
#  scale_edge_alpha_continuous(
#    name = "Probability\nof co-activation",
#    limits = c(0,1),
#    breaks = c(0.25,0.5,0.75)
#  ) +
#  scale_edge_width(
#    name = "Probability\nof co-activation",
#    limits = c(0,1),
#    breaks = c(0.25,0.5,0.75)
#  ) +
#  # extend border so that nodes are not cut off
#  coord_cartesian(
#    xlim = c(min(g.layout$x) - 0.35, max(g.layout$x) + 0.35),
#    ylim = c(min(g.layout$y) - 0.35, max(g.layout$y) + 0.35)
#  ) +
#  ggtitle("Evasive network")


#jpeg("Figures/EvasiveNetupdate.jpeg")
#evasivenetupdate.plot
#dev.off()
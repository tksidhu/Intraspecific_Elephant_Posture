### Elephant Posture Project: NetFACS analysis of elephant interaction posture data by activity and context
### Based on script by Kate Lewis NetFACS analysis of EquiFACS horse-horse data - by individual context https://osf.io/zmsvx/
# Created on: 20/09/2025 using AMBOSELI & APNR DATA
# Updated on: 02/10/2025 
# Owner: Tapinder Sidhu

###################################################################################################################

## Prepare environment ##

# Clear environment
rm(list=ls())

setwd("F:/06_Data_Analysis/PostureFilesAnalysis") #set working directory

###################################################################################################################

## Install packages ##


# installed devtools
# had to also install Rtools42 from online source (Rtools is a toolchain bundle used for building R packages from source (those that need compilation of C/C++ or Fortran code) and for building R itself)
# now can install NetFACS from GitHub
# will install development version of NetFACS: v0.5.0.9001
remove.packages("NetFACS")
remotes::install_github("NetFACS/NetFACS", ref = "73c2a29b")

library(tidyverse)
library(dplyr)
library(NetFACS)


###################################################################################################################

# upload data
full.data <- read.csv("Data/Posture_ForNetFACS.csv")


##############################################################

# ensure only APNR & Amboseli
keep.pops <- c("APNR", "Amboseli")
full.data1 <- full.data |>
  dplyr::filter(Population %in% keep.pops) |>
  droplevels()

write_csv(full.data1, "Data/Posture_ForNetFACS_AMBOAPNR.csv")

##############################################################

# split data
au.data <- full.data1 %>% select(EFold:HfStToe)
au.info <- full.data1 %>% select(X:Activity)

# check rows match
nrow(au.data) 
nrow(au.info)

# convert data to numeric, NA coercion is ok
au.data <- 
  au.data %>% 
  mutate(across(everything(), as.numeric)) %>% 
  as.matrix()

head(au.data)



####################################################################################################################




##################################### ANALYSIS BY BEHAVIOURAL GROUPS ############################################################

#### WITH MULTIFACS ####


set.seed(2025) # added - ensures same random distribution each time I run code


# this code is what netfacs.multiple does under the hood
# coding manually is necessary here because netfacs.multiple does not currently work when the data has NAs.
conditions <- sort(unique(au.info$Activity)) # Extracts and sorts all unique behaviour categories
ran.trials <- 1000 # sets number of random permutations (used for bootstrap sig testing)
multi.facs <- lapply(conditions, function(x) {
  xx <- netfacs_na( # all of this loops through each activity and netfacs_na() is custom version of main NetFACS func to handle NAs
    data = au.data,
    condition = au.info$Activity, # vector of behavioural categories for each row
    test.condition = x, # the current condition being tested against all others
    ran.trials = ran.trials, 
    combination.size = 2, 
    control = data.frame(Sex = au.info$Sex),  # add Sex as control
    random.level = au.info$RC,            # add record code as random level 
    use_parallel = FALSE,
    n_cores = parallel::detectCores()-1 # uses all but one core for parallel processing
  )
  return(xx) 
}) 
names(multi.facs) <- conditions # Names each element in multi.facs according to its behavioural condition
# set class and attributes
multi.facs <- structure(
  multi.facs, 
  class = "netfacs_multiple",
  stat_method = "bootstrap",
  random_trials = ran.trials
)


# save multi.facs object for later use
saveRDS(multi.facs, file="multi.facsupdateA20250918.rds")

# load multi.facs object
multi.facs <- readRDS("multi.facsupdateA20250918.rds")


# extract overall results with pvalues
(resupdateA20250918 <- netfacs_extract(multi.facs))
view(resupdateA20250918)

write.csv(resupdateA20250918, "Data/NetFACSExtractMultiFacsResUpdateA20250918.csv")

########################################################################################

################################################################################

### EXTRACT SIG AU/ADs FOR EACH BEHAVIOUR ####



## NON-AGONISTIC INTERACTIONS ##


Gen_Aff.pusupdateA <- netfacs_extract(
  netfacs.data = multi.facs$Gen_Aff,
  combination.size = 1,
  min.count = 5,
  min.prob = 0,
  significance = 0.01)

View(Gen_Aff.pusupdateA)
write.csv(Gen_Aff.pusupdateA, "Data/NetFACSGen_Aff.pusupdateA.csv")

Greeting.pusupdateA <- netfacs_extract(
  netfacs.data = multi.facs$Greeting,
  combination.size = 1,
  min.count = 5,
  min.prob = 0,
  significance = 0.01)

View(Greeting.pusupdateA)
write.csv(Greeting.pusupdateA, "Data/NetFACSGreeting.pusupdateA.csv")


## AGONISTIC INTERACTIONS ##


A_Charge.pusupdateA <- netfacs_extract(
  netfacs.data = multi.facs$A_Charge,
  combination.size = 1,
  min.count = 5,
  min.prob = 0,
  significance = 0.01)

View(A_Charge.pusupdateA)
write.csv(A_Charge.pusupdateA, "Data/NetFACSA_Charge.pusupdateA.csv")

A_Th_App.pusupdateA <- netfacs_extract(
  netfacs.data = multi.facs$A_Th_App,
  combination.size = 1,
  min.count = 5,
  min.prob = 0,
  significance = 0.01)

View(A_Th_App.pusupdateA)
write.csv(A_Th_App.pusupdateA, "Data/NetFACSA_Th_App.pusupdateA.csv")

A_Th_Sta.pusupdateA <- netfacs_extract(
  netfacs.data = multi.facs$A_Th_Sta,
  combination.size = 1,
  min.count = 5,
  min.prob = 0,
  significance = 0.01)

View(A_Th_Sta.pusupdateA)
write.csv(A_Th_Sta.pusupdateA, "Data/NetFACSA_Th_Sta.pusupdateA.csv")



## EVASIVE INTERACTIONS ##


A_Retreat.pusupdateA <- netfacs_extract(
  netfacs.data = multi.facs$A_Retreat,
  combination.size = 1,
  min.count = 5,
  min.prob = 0,
  significance = 0.01)

View(A_Retreat.pusupdateA)
write.csv(A_Retreat.pusupdateA, "Data/NetFACSA_Retreat.pusupdateA.csv")


########################################################################################


#### NETWORK PLOTS FOR EACH BEHAVIOUR ############




library(tidygraph)
library(ggraph)


##### NON-AGONISTIC INTERACTIONS #####

# General Affiliaiton #

Gen_Aff.netupdateA <- 
  netfacs_network(
    multi.facs$Gen_Aff, 
    link = "raw",
    min.prob = 0.1,
    min.count = 5
  )

network_plot(Gen_Aff.netupdateA, 
             plot.bubbles = TRUE)
network_plot(Gen_Aff.netupdateA)


g <- 
  Gen_Aff.netupdateA %>% 
  activate(nodes) %>% 
  # hide AUs not observed in this context
  tidygraph::filter(element.prob != 0 | !is.na(element.prob)) %>% 
  # keep only connections that are significant
  activate(edges) %>%
  filter(pvalue <= 0.01) 

g.nodes <- g %>% activate(nodes) %>% as_tibble()
g.edges <- g %>% activate(edges) %>% as_tibble() 

g.layout <- 
  g %>% 
  create_layout(
    layout = "igraph",
    algorithm = "kk" # other options: "kk", nicely", "dh"
  ) 

GenAffNetupdateA.plot <- g.layout %>% 
  ggraph() +
  geom_edge_fan(
    aes(alpha    = observed.prob,
        width    = observed.prob,
        linetype = observed.prob < 0.25)  # <-- dashed if < 0.25
  ) +
  geom_node_label(
    aes(label = name),
    color = "firebrick",
    size = 4,
    show.legend = FALSE
  ) +
  theme_graph(base_family = "sans") +
  scale_edge_alpha_continuous(
    name = "Probability\nof co-activation",
    limits = c(0,1),
    breaks = c(0.25, 0.5, 0.75)
  ) +
  scale_edge_width(
    name = "Probability\nof co-activation",
    limits = c(0,1),
    breaks = c(0.25, 0.5, 0.75)
  ) +
  scale_edge_linetype_manual(                    # optional legend for the dash rule
    values = c(`TRUE` = "22", `FALSE` = "solid"),
    labels = c(`TRUE` = "< 0.25", `FALSE` = "≥ 0.25"),
    name   = ""
    # If you do NOT want an extra legend, add:  guide = "none"
  ) +
  coord_cartesian(
    xlim = c(min(g.layout$x) - 0.35, max(g.layout$x) + 0.35),
    ylim = c(min(g.layout$y) - 0.35, max(g.layout$y) + 0.35)
  ) +
  ggtitle("General Affiliation Network")


jpeg("Figures/GenAffNetupdateA.jpeg")
GenAffNetupdateA.plot
dev.off()


# Greeting #

Greeting.netupdateA <- 
  netfacs_network(
    multi.facs$Greeting, 
    link = "raw",
    min.prob = 0.1,
    min.count = 5
  )

network_plot(Greeting.netupdateA, 
             plot.bubbles = TRUE)
network_plot(Greeting.netupdateA)


g <- 
  Greeting.netupdateA %>% 
  activate(nodes) %>% 
  # hide AUs not observed in this context
  tidygraph::filter(element.prob != 0 | !is.na(element.prob)) %>% 
  # keep only connections that are significant
  activate(edges) %>%
  filter(pvalue <= 0.01) 

g.nodes <- g %>% activate(nodes) %>% as_tibble()
g.edges <- g %>% activate(edges) %>% as_tibble() 

g.layout <- 
  g %>% 
  create_layout(
    layout = "igraph",
    algorithm = "kk" # other options: "kk", nicely", "dh"
  ) 

GreetingNetupdateA.plot <- g.layout %>% 
  ggraph() +
  geom_edge_fan(
    aes(alpha    = observed.prob,
        width    = observed.prob,
        linetype = observed.prob < 0.25)   # dashed if < 0.25
  ) +
  geom_node_label(
    aes(label = name),
    color = "firebrick",
    size = 4,
    show.legend = FALSE
  ) +
  theme_graph(base_family = "sans") +
  scale_edge_alpha_continuous(
    name = "Probability\nof co-activation",
    limits = c(0,1),
    breaks = c(0.25,0.5,0.75)
  ) +
  scale_edge_width(
    name = "Probability\nof co-activation",
    limits = c(0,1),
    breaks = c(0.25,0.5,0.75)
  ) +
  scale_edge_linetype_manual(
    values = c(`TRUE` = "22", `FALSE` = "solid"),
    labels = c(`TRUE` = "< 0.25", `FALSE` = "≥ 0.25"),
    name   = ""
  ) +
  coord_cartesian(
    xlim = c(min(g.layout$x) - 0.35, max(g.layout$x) + 0.35),
    ylim = c(min(g.layout$y) - 0.35, max(g.layout$y) + 0.35)
  ) +
  ggtitle("Greeting Network")


jpeg("Figures/GreetingNetupdateA.jpeg")
GreetingNetupdateA.plot
dev.off()

###################################################

##### AGONISTIC INTERACTIONS #####

# CHARGE #

A_Charge.netupdateA <- 
  netfacs_network(
    multi.facs$A_Charge, 
    link = "raw",
    min.prob = 0.1,
    min.count = 5
  )

network_plot(A_Charge.netupdateA, 
             plot.bubbles = TRUE)
network_plot(A_Charge.netupdateA)


g <- 
  A_Charge.netupdateA %>% 
  activate(nodes) %>% 
  # hide AUs not observed in this context
  tidygraph::filter(element.prob != 0 | !is.na(element.prob)) %>% 
  # keep only connections that are significant
  activate(edges) %>%
  filter(pvalue <= 0.01) 

g.nodes <- g %>% activate(nodes) %>% as_tibble()
g.edges <- g %>% activate(edges) %>% as_tibble() 

g.layout <- 
  g %>% 
  create_layout(
    layout = "igraph",
    algorithm = "kk" # other options: "kk", nicely", "dh"
  ) 

ChargeNetupdateA.plot <- g.layout %>% 
  ggraph() +
  geom_edge_fan(
    aes(alpha    = observed.prob,
        width    = observed.prob,
        linetype = observed.prob < 0.25)
  ) +
  geom_node_label(aes(label = name),
                  color = "firebrick", size = 4, show.legend = FALSE) +
  theme_graph(base_family = "sans") +
  scale_edge_alpha_continuous(
    name = "Probability\nof co-activation",
    limits = c(0,1),
    breaks = c(0.25,0.5,0.75)
  ) +
  scale_edge_width(
    name = "Probability\nof co-activation",
    limits = c(0,1),
    breaks = c(0.25,0.5,0.75)
  ) +
  scale_edge_linetype_manual(
    values = c(`TRUE` = "22", `FALSE` = "solid"),
    labels = c(`TRUE` = "< 0.25", `FALSE` = "≥ 0.25"),
    name   = ""
  ) +
  coord_cartesian(
    xlim = c(min(g.layout$x) - 0.35, max(g.layout$x) + 0.35),
    ylim = c(min(g.layout$y) - 0.35, max(g.layout$y) + 0.35)
  ) +
  ggtitle("Charge Network")


jpeg("Figures/ChargeNetupdateA.jpeg")
ChargeNetupdateA.plot
dev.off()


# A_Th_App #

A_Th_App.netupdateA <- 
  netfacs_network(
    multi.facs$A_Th_App, 
    link = "raw",
    min.prob = 0.1,
    min.count = 5
  )

network_plot(A_Th_App.netupdateA, 
             plot.bubbles = TRUE)
network_plot(A_Th_App.netupdateA)


g <- 
  A_Th_App.netupdateA %>% 
  activate(nodes) %>% 
  # hide AUs not observed in this context
  tidygraph::filter(element.prob != 0 | !is.na(element.prob)) %>% 
  activate(edges) %>%
  filter(pvalue <= 0.01) 

g.nodes <- g %>% activate(nodes) %>% as_tibble()
g.edges <- g %>% activate(edges) %>% as_tibble() 

g.layout <- 
  g %>% 
  create_layout(
    layout = "igraph",
    algorithm = "kk" # other options: "kk", nicely", "dh"
  ) 

ThreatAppNetupdateA.plot <- g.layout %>% 
  ggraph() +
  geom_edge_fan(
    aes(alpha    = observed.prob,
        width    = observed.prob,
        linetype = observed.prob < 0.25)
  ) +
  geom_node_label(aes(label = name),
                  color = "firebrick", size = 4, show.legend = FALSE) +
  theme_graph(base_family = "sans") +
  scale_edge_alpha_continuous(
    name = "Probability\nof co-activation",
    limits = c(0,1),
    breaks = c(0.25,0.5,0.75)
  ) +
  scale_edge_width(
    name = "Probability\nof co-activation",
    limits = c(0,1),
    breaks = c(0.25,0.5,0.75)
  ) +
  scale_edge_linetype_manual(
    values = c(`TRUE` = "22", `FALSE` = "solid"),
    labels = c(`TRUE` = "< 0.25", `FALSE` = "≥ 0.25"),
    name   = ""
  ) +
  coord_cartesian(
    xlim = c(min(g.layout$x) - 0.35, max(g.layout$x) + 0.35),
    ylim = c(min(g.layout$y) - 0.35, max(g.layout$y) + 0.35)
  ) +
  ggtitle("Threat Approach Network")


jpeg("Figures/ThreatAppNetupdateA.jpeg")
ThreatAppNetupdateA.plot
dev.off()



# A_Th_Sta #

A_Th_Sta.netupdateA <- 
  netfacs_network(
    multi.facs$A_Th_Sta, 
    link = "raw",
    min.prob = 0.1,
    min.count = 5
  )

network_plot(A_Th_Sta.netupdateA, 
             plot.bubbles = TRUE)
network_plot(A_Th_Sta.netupdateA)


g <- 
  A_Th_Sta.netupdateA %>% 
  activate(nodes) %>% 
  # hide AUs not observed in this context
  tidygraph::filter(element.prob != 0 | !is.na(element.prob)) %>% 
  activate(edges) %>%
  filter(pvalue <= 0.01) 

g.nodes <- g %>% activate(nodes) %>% as_tibble()
g.edges <- g %>% activate(edges) %>% as_tibble() 

g.layout <- 
  g %>% 
  create_layout(
    layout = "igraph",
    algorithm = "kk" # other options: "kk", nicely", "dh"
  ) 

ThreatStaNetupdateA.plot <- g.layout %>% 
  ggraph() +
  geom_edge_fan(
    aes(alpha    = observed.prob,
        width    = observed.prob,
        linetype = observed.prob < 0.25)
  ) +
  geom_node_label(aes(label = name),
                  color = "firebrick", size = 4, show.legend = FALSE) +
  theme_graph(base_family = "sans") +
  scale_edge_alpha_continuous(
    name = "Probability\nof co-activation",
    limits = c(0,1),
    breaks = c(0.25,0.5,0.75)
  ) +
  scale_edge_width(
    name = "Probability\nof co-activation",
    limits = c(0,1),
    breaks = c(0.25,0.5,0.75)
  ) +
  scale_edge_linetype_manual(
    values = c(`TRUE` = "22", `FALSE` = "solid"),
    labels = c(`TRUE` = "< 0.25", `FALSE` = "≥ 0.25"),
    name   = ""
  ) +
  coord_cartesian(
    xlim = c(min(g.layout$x) - 0.35, max(g.layout$x) + 0.35),
    ylim = c(min(g.layout$y) - 0.35, max(g.layout$y) + 0.35)
  ) +
  ggtitle("Threat Standing Network")


jpeg("Figures/ThreatStaNetupdateA.jpeg")
ThreatStaNetupdateA.plot
dev.off()


##### EVASIVE INTERACTIONS #####
# RETREAT #

A_Retreat.netupdateA <- 
  netfacs_network(
    multi.facs$A_Retreat, 
    link = "raw",
    min.prob = 0.1,
    min.count = 5
  )

network_plot(A_Retreat.netupdateA, 
             plot.bubbles = TRUE)
network_plot(A_Retreat.netupdateA)


g <- 
  A_Retreat.netupdateA %>% 
  activate(nodes) %>% 
  # hide AUs not observed in this context
  tidygraph::filter(element.prob != 0 | !is.na(element.prob)) %>%
  activate(edges) %>%
  filter(pvalue <= 0.01)%>%
  # remove nodes that have become isolated after edge filtering
  activate(nodes) %>%
  filter(!node_is_isolated()) 

g.nodes <- g %>% activate(nodes) %>% as_tibble()
g.edges <- g %>% activate(edges) %>% as_tibble() 

g.layout <- 
  g %>% 
  create_layout(
    layout = "igraph",
    algorithm = "kk" # other options: "kk", nicely", "dh"
  ) 

RetreatNetupdateA.plot <- g.layout %>% 
  ggraph() +
  geom_edge_fan(
    aes(alpha    = observed.prob,
        width    = observed.prob,
        linetype = observed.prob < 0.25)
  ) +
  geom_node_label(aes(label = name),
                  color = "firebrick", size = 4, show.legend = FALSE) +
  theme_graph(base_family = "sans") +
  scale_edge_alpha_continuous(
    name = "Probability\nof co-activation",
    limits = c(0,1),
    breaks = c(0.25,0.5,0.75)
  ) +
  scale_edge_width(
    name = "Probability\nof co-activation",
    limits = c(0,1),
    breaks = c(0.25,0.5,0.75)
  ) +
  scale_edge_linetype_manual(
    values = c(`TRUE` = "22", `FALSE` = "solid"),
    labels = c(`TRUE` = "< 0.25", `FALSE` = "≥ 0.25"),
    name   = ""
  ) +
  coord_cartesian(
    xlim = c(min(g.layout$x) - 0.35, max(g.layout$x) + 0.35),
    ylim = c(min(g.layout$y) - 0.35, max(g.layout$y) + 0.35)
  ) +
  ggtitle("Retreat Network")


jpeg("Figures/RetreatNetupdateA.jpeg")
RetreatNetupdateA.plot
dev.off()


##########################################################################################
#### ADDED BY TS: SAME AGAIN FOR AGONISTIC, NON AGONISTIC, EVASIVE ####

#### WITH MULTIFACS ####

set.seed(20255) 

conditionsCupdateA <- sort(unique(au.info$CSubcat)) # Extracts and sorts all unique Context Subcatagories
ran.trials <- 1000 # sets number of random permutations (used for bootstrap sig testing)
multi.facsCupdateA <- lapply(conditionsCupdateA, function(x) {
  xx <- netfacs_na( # all of this loops through each CSubcat and netfacs_na() is custom version of main NetFACS func to handle NAs
    data = au.data,
    condition = au.info$CSubcat, # vector of context categories for each row
    test.condition = x, # the current condition being tested against all others
    ran.trials = ran.trials, 
    combination.size = 2, 
    control = data.frame(Sex = au.info$Sex),  # add Sex as control
    random.level = au.info$RC,            # add RC as random level
    use_parallel = FALSE, 
    n_cores = parallel::detectCores()-1 # uses all but one core for parallel processing
  )
  return(xx) 
}) 
names(multi.facsCupdateA) <- conditionsCupdateA # Names each element in multi.facs according to its context condition
# set class and attributes
multi.facsCupdateA <- structure(
  multi.facsCupdateA, 
  class = "netfacs_multiple",
  stat_method = "bootstrap",
  random_trials = ran.trials
)


# save multi.facs object for later use
saveRDS(multi.facsCupdateA, file="multi.facsCupdateA.rds")

# load multi.facs object
multi.facsCupdateA <- readRDS("multi.facsCupdateA.rds")


# extract overall results with pvalues
(resCupdateA <- netfacs_extract(multi.facsCupdateA))
view(resCupdateA)

write.csv(resCupdateA, "Data/NetFACSExtractMultiFacsContextResupdateA.csv")

########################################################################################

################################################################################

### EXTRACT SIG AU/ADs FOR EACH CONTEXT ####



## NON-AGONISTIC INTERACTIONS ##


Affiliative.pusupdateA <- netfacs_extract(
  netfacs.data = multi.facsCupdateA$Affiliative,
  combination.size = 1,
  min.count = 5,
  min.prob = 0,
  significance = 0.01)

View(Affiliative.pusupdateA)
write.csv(Affiliative.pusupdateA, "Data/NetFACSAffiliative.pusupdateA.csv")


## AGONISTIC INTERACTIONS ##

Agonistic.pusupdateA <- netfacs_extract(
  netfacs.data = multi.facsCupdateA$Agonistic,
  combination.size = 1,
  min.count = 5,
  min.prob = 0,
  significance = 0.01)

View(Agonistic.pusupdateA)
write.csv(Agonistic.pusupdateA, "Data/NetFACSAgonistic.pusupdateA.csv")


## EVASIVE INTERACTIONS ##


Evasive.pusupdateA <- netfacs_extract(
  netfacs.data = multi.facsCupdateA$Evasive,
  combination.size = 1,
  min.count = 5,
  min.prob = 0,
  significance = 0.01)

View(Evasive.pusupdateA)
write.csv(Evasive.pusupdateA, "Data/NetFACSEvasive.pusupdateA.csv")

########################################################################################


#### NETWORK PLOTS FOR EACH CONTEXT ############


library(tidygraph)
library(ggraph)


##### NON-AGONISTIC INTERACTIONS #####

Affiliative.netupdateA <- 
  netfacs_network(
    multi.facsCupdateA$Affiliative, 
    link = "raw",
    min.prob = 0.1,
    min.count = 5
  )

network_plot(Affiliative.netupdateA, 
             plot.bubbles = TRUE)
network_plot(Affiliative.netupdateA)


g <- 
  Affiliative.netupdateA %>% 
  activate(nodes) %>% 
  # hide AUs not observed in this context
  tidygraph::filter(element.prob != 0 | !is.na(element.prob)) %>% 
  activate(edges) %>%
  filter(pvalue <= 0.01) 

g.nodes <- g %>% activate(nodes) %>% as_tibble()
g.edges <- g %>% activate(edges) %>% as_tibble() 

g.layout <- 
  g %>% 
  create_layout(
    layout = "igraph",
    algorithm = "kk" # other options: "kk", nicely", "dh"
  ) 

AffiliativeNetupdateA.plot <- g.layout %>% 
  ggraph() +
  geom_edge_fan(
    aes(alpha    = observed.prob,
        width    = observed.prob,
        linetype = observed.prob < 0.25)   # dashed if < 0.25
  ) +
  geom_node_label(
    aes(label = name),
    color = "firebrick",
    size = 4,
    show.legend = FALSE
  ) +
  theme_graph(base_family = "sans") +
  scale_edge_alpha_continuous(
    name = "Probability\nof co-activation",
    limits = c(0,1),
    breaks = c(0.25,0.5,0.75)
  ) +
  scale_edge_width(
    name = "Probability\nof co-activation",
    limits = c(0,1),
    breaks = c(0.25,0.5,0.75)
  ) + 
  scale_edge_linetype_manual(
    values = c(`TRUE` = "22", `FALSE` = "solid"),
    labels = c(`TRUE` = "< 0.25", `FALSE` = "≥ 0.25"),
    name   = ""
  ) +
  coord_cartesian(
    xlim = c(min(g.layout$x) - 0.35, max(g.layout$x) + 0.35),
    ylim = c(min(g.layout$y) - 0.35, max(g.layout$y) + 0.35)
  ) +
  ggtitle("Affiliative Network")

jpeg("Figures/AffiliativeNetupdateA.jpeg")
AffiliativeNetupdateA.plot
dev.off()



###################################################

##### AGONISTIC INTERACTIONS #####


Agonistic.netupdateA <- 
  netfacs_network(
    multi.facsCupdateA$Agonistic, 
    link = "raw",
    min.prob = 0.1,
    min.count = 5
  )

network_plot(Agonistic.netupdateA, 
             plot.bubbles = TRUE)
network_plot(Agonistic.netupdateA)


g <- 
  Agonistic.netupdateA %>% 
  activate(nodes) %>% 
  # hide AUs not observed in this context
  tidygraph::filter(element.prob != 0 | !is.na(element.prob)) %>% 
  activate(edges) %>%
  filter(pvalue <= 0.01) 

g.nodes <- g %>% activate(nodes) %>% as_tibble()
g.edges <- g %>% activate(edges) %>% as_tibble() 

g.layout <- 
  g %>% 
  create_layout(
    layout = "igraph",
    algorithm = "kk" # other options: "kk", nicely", "dh"
  ) 

AgonisticNetupdateA.plot <- g.layout %>% 
  ggraph() +
  geom_edge_fan(
    aes(alpha    = observed.prob,
        width    = observed.prob,
        linetype = observed.prob < 0.25)
  ) +
  geom_node_label(
    aes(label = name),
    color = "firebrick",
    size = 4,
    show.legend = FALSE
  ) +
  theme_graph(base_family = "sans") +
  scale_edge_alpha_continuous(
    name = "Probability\nof co-activation",
    limits = c(0,1),
    breaks = c(0.25,0.5,0.75)
  ) +
  scale_edge_width(
    name = "Probability\nof co-activation",
    limits = c(0,1),
    breaks = c(0.25,0.5,0.75)
  ) +
  scale_edge_linetype_manual(
    values = c(`TRUE` = "22", `FALSE` = "solid"),
    labels = c(`TRUE` = "< 0.25", `FALSE` = "≥ 0.25"),
    name   = ""
  ) +
  coord_cartesian(
    xlim = c(min(g.layout$x) - 0.35, max(g.layout$x) + 0.35),
    ylim = c(min(g.layout$y) - 0.35, max(g.layout$y) + 0.35)
  ) +
  ggtitle("Agonistic Network")


jpeg("Figures/AgonisticNetupdateA.jpeg")
AgonisticNetupdateA.plot
dev.off()



##### EVASIVE INTERACTIONS #####

Evasive.netupdateA <- 
  netfacs_network(
    multi.facsCupdateA$Evasive, 
    link = "raw",
    min.prob = 0.1,
    min.count = 5
  )

network_plot(Evasive.netupdateA, 
             plot.bubbles = TRUE)
network_plot(Evasive.netupdateA)


g <- 
  Evasive.netupdateA %>% 
  activate(nodes) %>% 
  # hide AUs not observed in this context
  tidygraph::filter(element.prob != 0 | !is.na(element.prob)) %>% 
  activate(edges) %>%
  filter(pvalue <= 0.01)%>%
  # remove nodes that have become isolated after edge filtering
  activate(nodes) %>%
  filter(!node_is_isolated()) 

g.nodes <- g %>% activate(nodes) %>% as_tibble()
g.edges <- g %>% activate(edges) %>% as_tibble() 

g.layout <- 
  g %>% 
  create_layout(
    layout = "igraph",
    algorithm = "kk" # other options: "kk", nicely", "dh"
  ) 

EvasiveNetupdateA.plot <- g.layout %>% 
  ggraph() +
  geom_edge_fan(
    aes(alpha    = observed.prob,
        width    = observed.prob,
        linetype = observed.prob < 0.25)
  ) +
  geom_node_label(
    aes(label = name),
    color = "firebrick",
    size = 4,
    show.legend = FALSE
  ) +
  theme_graph(base_family = "sans") +
  scale_edge_alpha_continuous(
    name = "Probability\nof co-activation",
    limits = c(0,1),
    breaks = c(0.25,0.5,0.75)
  ) +
  scale_edge_width(
    name = "Probability\nof co-activation",
    limits = c(0,1),
    breaks = c(0.25,0.5,0.75)
  ) +
  scale_edge_linetype_manual(
    values = c(`TRUE` = "22", `FALSE` = "solid"),
    labels = c(`TRUE` = "< 0.25", `FALSE` = "≥ 0.25"),
    name   = ""
  ) +
  coord_cartesian(
    xlim = c(min(g.layout$x) - 0.35, max(g.layout$x) + 0.35),
    ylim = c(min(g.layout$y) - 0.35, max(g.layout$y) + 0.35)
  ) +
  ggtitle("Evasive Network")


jpeg("Figures/EvasiveNetupdateA.jpeg")
EvasiveNetupdateA.plot
dev.off()

### Elephant Posture Project: NetFACS analysis of elephant interaction posture data - specificity and probability networks for individual Activities
### Based on script by Kate Lewis NetFACS analysis of EquiFACS horse-horse data - specificity and probability networks - with ind. behaviours https://osf.io/tymvr
# Created on: 09/10/2025 AMBO & APNR data only 
# Updated on: 30/01/2025
# Owner: Tapinder Sidhu


###################################################################################################################

## Prepare environment ##

# Clear environment
rm(list=ls())

setwd("F:/06_Data_Analysis/PostureFilesAnalysis") #set working directory

###################################################################################################################

## Install packages ##

# will install development version of NetFACS: v0.5.0.9001
remove.packages("NetFACS")
#install.packages("remotes")
library(remotes)
remotes::install_github("NetFACS/NetFACS", ref = "73c2a29b")

#install.packages("tidyverse")
library(tidyverse)
library(NetFACS)
library(readxl)


###################################################################################################################

## Upload and upsample data ##

# upload all data (in one df) 
all.data <- read.csv("Data/Posture_ForNetFACS_AMBOAPNR.csv")



# REMOVE ANYTHING THAT OCCURS < 5 TIMES - NOT RELEVENT TO US
# all.data <- subset(all.data, !(Activity %in% c("Activity1", "Activity2", "Activity3")))


# UPSAMPLE - as imbalanced number of observations per group causes specificity results to be biased

# First check current numbers of each behaviour
head(all.data %>% count(Activity), n=22)
#Activity   n
#1  A_Charge 258
#2 A_Retreat 676
#3  A_Th_App 549
#4  A_Th_Sta  87
#5   Gen_Aff 178
#6  Greeting 439

# randomly upsample minority conditions to have the same number of observations as the majority condition

set.seed(2)

all.data.upsampled <- upsample(all.data, 
                               condition = all.data$Activity)
# check it has worked
print(all.data.upsampled %>% count(Activity), n=22) # all conditions now have 676 observations


# SPLIT all.data.upsampled into seperate DATA AND INFO dfs (needed in this format for running multi.facs)
au.info <- all.data.upsampled %>% select(X:Activity)
au.data <- all.data.upsampled %>% select(EFold:HfStToe)


# check same number of rows in each
nrow(au.data)
nrow(au.info)
#4056

# convert data to numeric, NA coercion is ok
au.data <- 
  au.data %>% 
  mutate(across(everything(), as.numeric)) %>% 
  as.matrix()

head(au.data)


####################################################################################################################



##################################### ANALYSIS BY BEHAVIOURs ############################################################


#### WITH MULTIFACS ####


set.seed(20255) # added myself - ensures same random distribution each time I run code 

# this code is what netfacs.multiple does under the hood
# I'm coding it manually here because netfacs.multiple does not currently work when the data has NAs.
conditions <- sort(unique(au.info$Activity))
ran.trials <- 1000
multi.facs <- lapply(conditions, function(x) {
  xx <- netfacs_na(
    data = au.data,
    condition = au.info$Activity,
    test.condition = x,
    ran.trials = ran.trials, 
    combination.size = 2,
    control = data.frame(Sex = au.info$Sex),  # add Sex as control
    random.level = au.info$RC,            # add RC as random level
    use_parallel = TRUE,
    n_cores = parallel::detectCores()-1
  )
  return(xx)
})
names(multi.facs) <- conditions
# set class and attributes
multi.facs <- structure(
  multi.facs, 
  class = "netfacs_multiple",
  stat_method = "bootstrap",
  random_trials = ran.trials
)


# save multi.facs object for later use
saveRDS(multi.facs, file="multi.facs.activityspecupdateA.rds")

# load multi.facs object
multi.facs <- readRDS("multi.facs.activityspecupdateA.rds")

# extract overall results with pvalues
(resAcSpecupdateA <- netfacs_extract(multi.facs))
view(resAcSpecupdateA)

write.csv(resAcSpecupdateA, "Data/NetFACSExtractMultiFacsResActivitiesforSpecificityUpdateA.csv")



##########################################################################################################

#### CALCULATING SPECIFICITY ####



library(dplyr)

# netfacs() function no longer calculates specificity, so it has to be calculated separately
# imbalanced number of observations per group causes specificity results to be biased

# Check we still have same number for each behaviour (from upsampling earier)
print(au.info %>% count(Activity), n=22) # yes, 676 obs for each behaviour


# calculate specificity from netfacs results 
set.seed(1)
sp.behav <- specificity(
  multi.facs, 
  combination.size = 3, 
)


# view combinations with top 5 highest specificity per context
sp1 <- sp.behav %>% 
  group_by(condition) %>% 
  slice_max(order_by = specificity, n = 5)

# view combinations with top 5 observed probabilities per context
sp.behav %>% 
  group_by(condition) %>% 
  slice_max(order_by = observed.prob, n = 5)

# consider filtering for combinations that are common AND have high specificity
sp3<- sp.behav %>% 
  filter(
    observed.prob >= 0.25, # combinations present in at least 25% of obs
    specificity >= 0.5, 
  ) 


################################################################################

#### SPECIFICITY VIOLIN PLOTS ####


# summarise specificity results
sp.behav.summaryupdateA <- 
  sp.behav %>% 
  # optional filtering. 
  # The combination count should be at least the same number as the number of conditions. Otherwise an AU combination that is only observed once will have a specificity of 1, but only because it never had the chance to be observed in another context.
  filter(
    observed.prob >= 0.10, # combination observed in >= 10% of cases
    count >= length(unique(sp.behav$condition))
  ) %>%
  group_by(condition) %>%
  summarise(across(
    specificity,
    list(
      mean = mean,
      median = median,
      min = min,
      max = max,
      sd = sd,
      n = ~n()
    ),
    .names = "{.fn}"
  ), .groups = "keep")

View(sp.behav.summaryupdateA)
write.csv(sp.behav.summaryupdateA, "Data/NetFACSSpecificityActivitiesupdateA.csv")


SpecActupdateA.plot <- sp.behav %>%
  # use same filter as for the summary
  filter(
    observed.prob >= 0.1, 
    count >= length(unique(sp.behav$condition))
  ) %>%
  # plot
  ggplot(aes(condition, specificity, fill=condition)) +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(),
        panel.background = element_blank(), axis.line = element_line(colour = "black"),
        axis.title = element_text(size = 15, face = "bold"),
        axis.title.y = element_text(margin = margin(t = 0, r = 10, b = 0, l = 0)),
        axis.title.x = element_text(margin = margin(t = 10, r = 0, b = 0, l = 0)),
        axis.text = element_text(size = 10, color = "black")) +
  geom_violin(alpha = 0.2,
              show.legend = FALSE) +
  geom_point(position = position_jitter(width = 0.3),
             aes(color = condition),
             show.legend = FALSE,
             alpha = 0.15) +
  geom_point(data = sp.behav.summaryupdateA,
             aes(condition, mean),
             show.legend = FALSE,
             fill = "white",
             color = "black",
             shape = 23,
             size = 3.5) +
  xlab("Behaviour") +
  ylab("Specificity") +
  scale_x_discrete(
    limits = c("General Affiliation", "Greeting", "Threat Stand", "Threat Approach", "Charge", "Retreat"),
    labels = c("General Affiliation", "Greeting", "Threat Stand", 
               "Threat Approach", "Charge", "Retreat")
  ) +
  scale_fill_manual(values = c("General Affiliation" = "#00BFC4", "Greeting" = "#0099B3", 
                               "Charge" = "#C77CFF", "Threat Approach" = "#9F59E6", 
                               "Threat Stand" = "#8A47D1", "Retreat" = "#84C800")) +
  scale_color_manual(values = c("General Affiliation" = "#00BFC4", "Greeting" = "#0099B3", 
                                "Charge" = "#C77CFF", "Threat Approach" = "#9F59E6", 
                                "Threat Stand" = "#8A47D1", "Retreat" = "#84C800"))


# Save the plot
ggsave("Figures/SpecificityActivitiesViolinPlotupdateA.png", plot = SpecActupdateA.plot, width = 10, height = 8, dpi = 300)

